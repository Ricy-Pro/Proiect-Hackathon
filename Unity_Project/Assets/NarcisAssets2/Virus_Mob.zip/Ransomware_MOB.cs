using UnityEngine;

public class Ransomware_MOB : MOB
{
    
}
