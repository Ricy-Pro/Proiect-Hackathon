using UnityEngine;

public class Trojan_Mob : MOB
{
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    



}
